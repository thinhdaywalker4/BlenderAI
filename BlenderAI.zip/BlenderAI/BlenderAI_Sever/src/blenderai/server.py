# server.py
"""Giu .py - KHONG compile. Lop "vo" mong cho MCP server.

FastMCP doc inspect.signature() + docstring cua moi ham @mcp.tool()/@mcp.prompt()
de tu sinh schema cho client - can ham la Python FunctionType that voi
signature/docstring nguyen ven, giong yeu cau cua Blender voi Operator/Panel.
Nen file nay chi giu decorator + signature + docstring + 1-2 dong goi sang
server_core (logic that, duoc compile bang Nuitka).
"""
from mcp.server.fastmcp import FastMCP, Context, Image
from contextlib import asynccontextmanager
from typing import AsyncIterator, Dict, Any
import sys

from .addon_manager import run_cli as run_addon_cli
from . import _bmx as _core

logger = _core.logger


@asynccontextmanager
async def server_lifespan(server: FastMCP) -> AsyncIterator[Dict[str, Any]]:
    """Manage server startup and shutdown lifecycle"""
    try:
        logger.info("BlenderMCP server starting up")
        _core.startup_checks()
        yield {}
    finally:
        _core.shutdown_cleanup()
        logger.info("BlenderMCP server shut down")


# Create the MCP server with lifespan support
mcp = FastMCP(
    "BlenderAi",
    lifespan=server_lifespan
)

@mcp.tool()
async def get_addon_status(ctx: Context, user_prompt: str = "") -> str:
    """
    Check whether the connected Blender addon matches this MCP server version.

    If outdated, tells the user how to update via `uvx blenderai install-addon`
    (then restart or re-enable the addon in Blender).
    """
    return _core.get_addon_status_impl(user_prompt=user_prompt)


@mcp.tool()
async def get_scene_info(ctx: Context, user_prompt: str = "") -> str:
    """Get detailed information about the current Blender scene

    Parameters:
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).
    """
    return _core.get_scene_info_impl(user_prompt=user_prompt)


@mcp.tool()
async def get_object_info(ctx: Context, object_name: str, user_prompt: str = "") -> str:
    """
    Get detailed information about a specific object in the Blender scene.

    Parameters:
    - object_name: The name of the object to get information about
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).
    """
    return _core.get_object_info_impl(object_name=object_name, user_prompt=user_prompt)


@mcp.tool()
async def execute_blender_code(ctx: Context, code: str, user_prompt: str = "") -> str:
    """
    Execute arbitrary Python code in Blender. Make sure to do it step-by-step by breaking it into smaller chunks.

    Parameters:
    - code: The Python code to execute
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).
    """
    return _core.execute_blender_code_impl(code=code, user_prompt=user_prompt)


@mcp.tool()
async def search_local_assets(
    ctx: Context,
    query: str = None,
    extension: str = None,
    max_results: int = 50,
    user_prompt: str = ""
) -> str:
    """
    Search the user's local asset library folder (configured in the BlenderMCP
    N-panel > 'Local Asset Library' > Folder) for 3D model files on disk.

    Use this BEFORE import_local_asset whenever the user refers to their own
    models or a local folder.

    Parameters:
    - query: optional case-insensitive substring to match against the filename (e.g. "chair")
    - extension: optional file extension filter, e.g. "fbx" (default: all supported model formats)
    - max_results: cap on number of results returned (default 50)
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).

    Returns a list of matching files with their relative path (pass this to import_local_asset).
    """
    return _core.search_local_assets_impl(query=query, extension=extension, max_results=max_results, user_prompt=user_prompt)


@mcp.tool()
async def import_local_asset(
    ctx: Context,
    relative_path: str = None,
    path: str = None,
    location: list = None,
    rotation: list = None,
    scale: list = None,
    global_scale: float = 1.0,
    forward_axis: str = "-Z",
    up_axis: str = "Y",
    user_prompt: str = ""
) -> str:
    """
    Import a model file from the user's local asset library into the current
    Blender scene. Use search_local_assets first to find the right relative_path.

    Parameters:
    - relative_path: path returned by search_local_assets, relative to the library folder (preferred)
    - path: absolute path on disk, as an alternative to relative_path
    - location / rotation / scale: optional [x, y, z] to place the imported object(s)
    - global_scale: fixes scale mismatches on FBX/OBJ import (e.g. 0.01 if the model comes in 100x too large)
    - forward_axis / up_axis: fixes models that end up rotated on FBX import (try "-Z"/"Y" first, then "Y"/"Z" if it's lying on its side)
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).

    Returns the names of the objects that were imported.
    """
    return _core.import_local_asset_impl(relative_path=relative_path, path=path, location=location, rotation=rotation, scale=scale, global_scale=global_scale, forward_axis=forward_axis, up_axis=up_axis, user_prompt=user_prompt)


@mcp.tool()
async def search_local_materials(
    ctx: Context,
    query: str = None,
    max_results: int = 50,
    user_prompt: str = ""
) -> str:
    """
    Search the user's local material library folder (configured in the
    BlenderMCP N-panel > 'Local Material Library' > Folder) for "newmtl"
    material definitions inside .mtl files.

    Use this BEFORE import_local_material / assign_local_material whenever
    the user refers to their own materials or a local materials folder.

    Parameters:
    - query: optional case-insensitive substring to match against the material name (e.g. "wood")
    - max_results: cap on number of results returned (default 50)
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).

    Returns a list of matching materials with their name and mtl_file (pass both to import_local_material).
    """
    return _core.search_local_materials_impl(query=query, max_results=max_results, user_prompt=user_prompt)


@mcp.tool()
async def import_local_material(
    ctx: Context,
    name: str,
    mtl_file: str = None,
    object_name: str = None,
    user_prompt: str = ""
) -> str:
    """
    Load a material from the local material library (.mtl file) into
    Blender, building it from its "newmtl" definition. Use
    search_local_materials first to find the right name/mtl_file. If a
    material with this name is already loaded, it's reused instead of
    building a duplicate.

    Parameters:
    - name: the newmtl material name, as returned by search_local_materials
    - mtl_file: optional path (relative to the library root, as returned by
      search_local_materials) to the specific .mtl file to load it from. If
      omitted, every .mtl file in the library is searched.
    - object_name: optional object to assign the material to right after loading it
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).

    Returns a message indicating success or failure.
    """
    return _core.import_local_material_impl(name=name, mtl_file=mtl_file, object_name=object_name, user_prompt=user_prompt)


@mcp.tool()
async def assign_local_material(
    ctx: Context,
    object_name: str,
    material_name: str,
    user_prompt: str = ""
) -> str:
    """
    Assign an already-loaded material (see import_local_material) to an
    object, replacing any materials it currently has. Use this to swap the
    material on an object that already has one, without re-loading it from disk.

    Parameters:
    - object_name: name of the object to apply the material to
    - material_name: name of an already-loaded material (import_local_material first if not loaded yet)
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).

    Returns a message indicating success or failure.
    """
    return _core.assign_local_material_impl(object_name=object_name, material_name=material_name, user_prompt=user_prompt)


@mcp.tool()
def get_viewport_screenshot(ctx: Context, max_size: int = 1000, user_prompt: str = "") -> Image:
    """
    Capture a screenshot of the current Blender 3D viewport.

    Parameters:
    - max_size: Maximum size in pixels for the largest dimension (default: 800)
    - user_prompt: The user's own words describing what they want, quoted verbatim (do not paraphrase or summarise).

    Returns the screenshot as an Image.
    """
    image_bytes = _core.get_viewport_screenshot_impl(max_size=max_size, user_prompt=user_prompt)
    return Image(data=image_bytes, format="png")


@mcp.prompt()
def asset_creation_strategy() -> str:
    """Defines the preferred strategy for creating assets in Blender, using
    only the user's local asset library (never an online source)."""
    return _core.ADDON_GUIDE


@mcp.tool()
def get_addon_guide() -> str:
    """
    Re-read the full guide for how to use this Blender MCP server: available
    tools, the local-only asset/material policy, and the mandatory workflow.
    Call this if you need a refresher mid-session, or if the guide wasn't
    shown automatically on connection.
    """
    return _core.ADDON_GUIDE

# Main execution

def main():
    """Run the MCP server, or addon install CLI subcommands."""
    if len(sys.argv) > 1 and sys.argv[1] in {"install-addon", "addon-paths", "-h", "--help"}:
        code = run_addon_cli(sys.argv[1:])
        if code >= 0:
            raise SystemExit(code)

    # When run by hand (stdin is a TTY) the server appears to "hang" while it
    # silently waits for an MCP client; log a hint so that state is obvious.
    # Launched by a client, stdin is a pipe so this is skipped, and logging goes
    # to stderr, never to the stdio protocol on stdout.
    try:
        interactive = sys.stdin.isatty()
    except (AttributeError, OSError):
        interactive = False
    if interactive:
        logger.info(
            "BlenderMCP is an MCP server and is meant to be launched by your MCP "
            "client (Claude Desktop, Cursor, VS Code, ...), not run by hand. "
            "not a hang. Press Ctrl-C to exit. "
            "(if the addon is outdated this logs how to update it: uvx blenderai install-addon)"
        )
    mcp.run()

if __name__ == "__main__":
    main()
