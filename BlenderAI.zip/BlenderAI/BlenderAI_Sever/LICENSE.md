# BlenderAI — Personal License

**Copyright (c) 2026 Thinh Nguyen. All rights reserved.**
Contact: thinhdaywalker4@gmail.com

This is a personal-use license. By downloading, installing, or using
BlenderAI (the "Software"), you agree to the following terms.

## 1. Grant

You are granted a personal, non-exclusive, non-transferable license to
install and use the Software for your own use.

## 2. Restrictions

You may **not**:

- **Share, distribute, publish, upload, post, or otherwise make the
  Software (or any part of it) available to any third party** — including
  sharing installers or files, posting on file-sharing sites, cloud
  drives, Discord/Telegram groups, forums, or marketplaces;
- **Sell, resell, rent, lease, lend, or sublicense** the Software or any
  copy of it;
- **Reverse engineer, decompile, disassemble, decrypt, or otherwise
  attempt to derive the source code**, underlying ideas, or algorithms of
  the Software or any of its compiled components (e.g. `.pyd`, `.so`,
  `.dll`, `.pyc`), except to the extent this restriction is expressly
  prohibited by applicable law;
- Remove, obscure, or alter any copyright or proprietary notice included
  in the Software.

The restrictions above apply to you as a user of the Software. They do
not restrict the Licensor from distributing or hosting the Software
through the Licensor's own official channels (e.g. the official GitHub
repository or website).

## 3. Ownership

The Software is licensed, not sold. The Licensor retains all right,
title, and interest in the Software, including all intellectual property
rights. This license does not grant you any ownership interest in it.

## 4. Third-Party / Inherited Open-Source Component

BlenderAI incorporates code originally developed as part of the
**blender-mcp** project (https://github.com/ahujasid/blender-mcp),
originally licensed under the MIT License:

> Copyright (c) ahujasid (blender-mcp)
>
> Permission is hereby granted, free of charge, to any person obtaining a
> copy of this software and associated documentation files (the
> "Software"), to deal in the Software without restriction, including
> without limitation the rights to use, copy, modify, merge, publish,
> distribute, sublicense, and/or sell copies of the Software, and to
> permit persons to whom the Software is furnished to do so, subject to
> the following conditions: The above copyright notice and this
> permission notice shall be included in all copies or substantial
> portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT
> WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
> THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
> NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
> LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
> OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
> WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

This notice is preserved here as required by the MIT License. It does not
grant you any rights beyond those in Sections 1–2 above for BlenderAI's
own code, modifications, and compiled components. Nothing here restricts
a third party's independent right to obtain and use the original,
unmodified blender-mcp code from its original source under the MIT
License.

## 5. No Warranty

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT. THE LICENSOR IS
NOT LIABLE FOR ANY DAMAGES ARISING FROM THE USE OF THE SOFTWARE.

## 6. Contact

Questions about this license should be sent to:
**thinhdaywalker4@gmail.com**
