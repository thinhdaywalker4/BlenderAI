@echo off
setlocal enabledelayedexpansion
title Python Version Check

echo ================================================
echo   PYTHON CHECK (requires 3.10 - 3.14, 64-bit)
echo ================================================
echo.

set "PYTHON_CMD="
set "FOUND_VALID=0"
set "PY_MAJOR_MINOR="
set "PY_PATCH="
set "PY_ARCH="

REM --- Find an available Python command on this machine ---
for %%P in (python python3 py) do (
    where %%P >nul 2>nul
    if !errorlevel! equ 0 (
        if "!PYTHON_CMD!"=="" set "PYTHON_CMD=%%P"
    )
)

if "%PYTHON_CMD%"=="" (
    echo [X] No installed Python found on this machine.
    goto :NOT_FOUND
)

echo Found Python command: %PYTHON_CMD%
echo.

REM --- Ask Python itself for its exact version and architecture ---
for /f "usebackq tokens=1,2,3 delims=|" %%A in (`%PYTHON_CMD% -c "import sys,platform;print(str(sys.version_info[0])+'.'+str(sys.version_info[1])+'|'+str(sys.version_info[2])+'|'+platform.machine())" 2^>nul`) do (
    set "PY_MAJOR_MINOR=%%A"
    set "PY_PATCH=%%B"
    set "PY_ARCH=%%C"
)

if "%PY_MAJOR_MINOR%"=="" (
    echo [X] Could not read the Python version. The installation may be broken.
    goto :NOT_FOUND
)

echo Detected version      : %PY_MAJOR_MINOR%.%PY_PATCH%
echo Detected architecture : %PY_ARCH%
echo.

REM --- Require the AMD64 (x64) architecture ---
if /I not "%PY_ARCH%"=="AMD64" (
    echo [X] The installed Python is not 64-bit ^(AMD64^). Detected architecture: %PY_ARCH%
    goto :NOT_FOUND
)

REM --- Split major/minor to check the 3.10 - 3.14 range ---
for /f "tokens=1,2 delims=." %%X in ("%PY_MAJOR_MINOR%") do (
    set "MAJOR=%%X"
    set "MINOR=%%Y"
)

if not "%MAJOR%"=="3" (
    echo [X] Python is not on the 3.x branch.
    goto :NOT_FOUND
)

if %MINOR% LSS 10 (
    echo [X] Python version is too old ^(3.10 or newer required^). Current: 3.%MINOR%
    goto :NOT_FOUND
)

if %MINOR% GTR 14 (
    echo [X] Python version is newer than supported ^(3.14 max^). Current: 3.%MINOR%
    goto :NOT_FOUND
)

set "FOUND_VALID=1"

:RESULT
if "%FOUND_VALID%"=="1" goto :VALID
goto :NOT_FOUND

:VALID
echo ================================================
echo   [OK] Valid Python found: %PY_MAJOR_MINOR%.%PY_PATCH% ^(%PY_ARCH%^)
echo ================================================
echo.

REM --- Move to the folder containing this .bat file ---
pushd "%~dp0"

echo Checking / installing pip...
%PYTHON_CMD% -m ensurepip --upgrade >nul 2>nul
%PYTHON_CMD% -m pip install --upgrade pip
if errorlevel 1 (
    echo [X] Failed to install/upgrade pip.
    popd
    pause
    exit /b 1
)
echo.

echo Installing project ^(pip install -e .^)...
%PYTHON_CMD% -m pip install -e .
if errorlevel 1 (
    echo [X] Project installation failed. Please check setup.py / pyproject.toml.
    popd
    pause
    exit /b 1
)
echo.

echo Detecting installed Blender versions and installing the matching addon...
echo ^(this may take a moment per Blender version found^)
echo ================================================

set "ADDON_PS1=%~dp0install_blenderai_addons.ps1"

if not exist "%ADDON_PS1%" (
    echo [!] install_blenderai_addons.ps1 not found next to this script - skipping addon installation.
) else (
    for /f "usebackq tokens=1-4 delims=|" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%ADDON_PS1%" 2^>nul`) do (
        if "%%A"=="NO_BLENDER_FOUND" (
            echo   [!] No installed Blender found on this machine. Addon was not installed.
        )
        if "%%A"=="OK" (
            echo   [OK] %%B ^(%%C^) - installed %%D
        )
        if "%%A"=="FAIL" (
            echo   [X] %%B ^(%%C^) - failed to install %%D
        )
        if "%%A"=="SKIP" (
            echo   [-] %%B ^(%%C^) - skipped: %%D
        )
    )
)
echo ================================================
echo.

echo Setting up Claude Desktop configuration...
echo ================================================
call :REPLACE_CLAUDE_CONFIG
echo ================================================
echo.

echo Launching application: python -m blenderai.main
echo ================================================

REM Launch in the background using plain "start" (never blocks/hangs)
start "BlenderAI" /min %PYTHON_CMD% -m blenderai.main

echo Waiting for BlenderAI to initialize...

set "LAUNCH_OK=0"
set "POLL_COUNT=0"

:POLL_LAUNCH
timeout /t 1 /nobreak >nul
set /a POLL_COUNT+=1

set "RUNNING_COUNT=0"
for /f "usebackq delims=" %%R in (`powershell -NoProfile -Command "(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*blenderai.main*' }).Count" 2^>nul`) do set "RUNNING_COUNT=%%R"

if not "%RUNNING_COUNT%"=="0" (
    set "LAUNCH_OK=1"
    goto :LAUNCH_DONE
)

if %POLL_COUNT% LSS 20 goto :POLL_LAUNCH

:LAUNCH_DONE

echo Stopping BlenderAI process...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*blenderai.main*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>nul

set "STILL_RUNNING=1"
set "KILL_POLL=0"

:POLL_KILL
timeout /t 1 /nobreak >nul
set /a KILL_POLL+=1

set "STILL_RUNNING=0"
for /f "usebackq delims=" %%R in (`powershell -NoProfile -Command "(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*blenderai.main*' }).Count" 2^>nul`) do set "STILL_RUNNING=%%R"

if "%STILL_RUNNING%"=="0" goto :KILL_DONE
if %KILL_POLL% LSS 8 goto :POLL_KILL

:KILL_DONE

if not "%STILL_RUNNING%"=="0" (
    echo [!] Warning: could not confirm the process was stopped. You may need to close it manually in Task Manager.
)

echo ================================================
if "%LAUNCH_OK%"=="1" (
    echo   [OK] BlenderAI launched successfully.
) else (
    echo   [X] BlenderAI did NOT launch successfully.
    echo   Run "%PYTHON_CMD% -m blenderai.main" manually in a terminal to see the error.
)
echo ================================================

popd
echo.
pause
exit /b 0

:NOT_FOUND
echo.
echo ================================================
echo   REQUIREMENTS NOT MET
echo   Please install Python 3.10 to 3.14, 64-bit ^(AMD64^)
echo   Official download page: https://www.python.org/downloads/windows/
echo ================================================
echo.
choice /M "Do you want to open the Python download page now"
if errorlevel 2 goto :END
start "" "https://www.python.org/downloads/windows/"

:END
pause
exit /b 1

REM ============================================================
REM Subroutine: REPLACE_CLAUDE_CONFIG
REM Finds claude_desktop_config.json in the same folder as this
REM .bat file and replaces the actual config file(s) used by
REM Claude Desktop (normal install path and, if present, the
REM Microsoft Store MSIX install path).
REM ============================================================
:REPLACE_CLAUDE_CONFIG
set "CFG_SRC_FILE=%~dp0claude_desktop_config.json"

set "CFG_DEST1_DIR=%APPDATA%\Claude"
set "CFG_DEST1_FILE=%CFG_DEST1_DIR%\claude_desktop_config.json"

set "CFG_DEST2_DIR="
for /d %%D in ("%LOCALAPPDATA%\Packages\Claude_*") do set "CFG_DEST2_DIR=%%D\LocalCache\Roaming\Claude"
if defined CFG_DEST2_DIR set "CFG_DEST2_FILE=%CFG_DEST2_DIR%\claude_desktop_config.json"

if not exist "%CFG_SRC_FILE%" (
    echo   [!] claude_desktop_config.json not found next to this script - skipping.
    echo   Place claude_desktop_config.json in: %~dp0
    goto :EOF
)

echo   Source file          : %CFG_SRC_FILE%
echo   Destination normal   : %CFG_DEST1_FILE%
if defined CFG_DEST2_DIR echo   Destination MSIX     : %CFG_DEST2_FILE%

if not exist "%CFG_DEST1_DIR%" mkdir "%CFG_DEST1_DIR%"

if exist "%CFG_DEST1_FILE%" (
    set "CFG_TS=%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
    set "CFG_TS=!CFG_TS: =0!"
    copy /Y "%CFG_DEST1_FILE%" "%CFG_DEST1_DIR%\claude_desktop_config.json.bak_!CFG_TS!" >nul
    echo   Backed up old file as claude_desktop_config.json.bak_!CFG_TS!
)

copy /Y "%CFG_SRC_FILE%" "%CFG_DEST1_FILE%" >nul
if errorlevel 1 (
    echo   [X] Failed to copy file to: %CFG_DEST1_FILE%
) else (
    echo   [OK] Replaced file at: %CFG_DEST1_FILE%
)

if defined CFG_DEST2_DIR (
    if not exist "%CFG_DEST2_DIR%" mkdir "%CFG_DEST2_DIR%"

    if exist "%CFG_DEST2_FILE%" (
        set "CFG_TS2=%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
        set "CFG_TS2=!CFG_TS2: =0!"
        copy /Y "%CFG_DEST2_FILE%" "%CFG_DEST2_DIR%\claude_desktop_config.json.bak_!CFG_TS2!" >nul
        echo   Backed up old MSIX file as claude_desktop_config.json.bak_!CFG_TS2!
    )

    copy /Y "%CFG_SRC_FILE%" "%CFG_DEST2_FILE%" >nul
    if errorlevel 1 (
        echo   [X] Failed to copy file to: %CFG_DEST2_FILE%
    ) else (
        echo   [OK] Replaced file at: %CFG_DEST2_FILE%
    )
) else (
    echo   [INFO] No Microsoft Store MSIX installation of Claude Desktop detected, skipping.
)

goto :EOF
