<#
    install_blenderai_addons.ps1

    Detects every installed Blender version on this machine, works out which
    Python version each one bundles, and installs + enables the matching
    BlenderAI addon zip (found in this same folder) via Blender itself.

    Expected addon zip naming convention in this folder (separator before
    "cp" can be "_" or "-", it does not matter):
        *cp10*.zip  -> for Blender builds running Python 3.10
        *cp11*.zip  -> for Blender builds running Python 3.11
        *cp13*.zip  -> for Blender builds running Python 3.13

    Output: one line per Blender install found, in the form
        OK|<blender.exe>|<version string>|<zip used>
        FAIL|<blender.exe>|<version string>|<zip used>
        SKIP|<blender.exe>|<version string>|<reason>
        NO_BLENDER_FOUND
    so the calling .bat file can parse and display it.
#>

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Get-BlenderInstalls {
    $found = New-Object System.Collections.Generic.List[string]

    # 1) Registry uninstall entries (64-bit, 32-bit, and per-user installs)
    $regPaths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($rp in $regPaths) {
        Get-ItemProperty -Path $rp -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -like "Blender*" -and $_.InstallLocation } |
            ForEach-Object {
                $exe = Join-Path $_.InstallLocation "blender.exe"
                if (Test-Path $exe) { $found.Add($exe) }
            }
    }

    # 2) Common install folders (catches installs the registry scan misses)
    $commonRoots = @(
        "$env:ProgramFiles\Blender Foundation",
        "${env:ProgramFiles(x86)}\Blender Foundation"
    )
    foreach ($root in $commonRoots) {
        if (Test-Path $root) {
            Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                $exe = Join-Path $_.FullName "blender.exe"
                if (Test-Path $exe) { $found.Add($exe) }
            }
        }
    }

    $found | Select-Object -Unique
}

function Get-BlenderPythonMinor {
    param([string]$BlenderExe)
    try {
        $out = & $BlenderExe -b --python-expr "import sys;print('PYVER:'+str(sys.version_info[1]))" 2>$null
        $line = $out | Where-Object { $_ -match '^PYVER:(\d+)$' } | Select-Object -First 1
        if ($line) {
            return ($line -replace '^PYVER:', '')
        }
    } catch {}
    return $null
}

function Get-BlenderVersionString {
    param([string]$BlenderExe)
    try {
        $out = & $BlenderExe -b --version 2>$null
        $line = $out | Select-Object -First 1
        if ($line) { return $line.Trim() }
    } catch {}
    return "unknown version"
}

function Get-ZipTopFolder {
    param([string]$ZipPath)
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
        $entry = $zip.Entries | Where-Object { $_.FullName -match '/' } | Select-Object -First 1
        $top = $null
        if ($entry) { $top = $entry.FullName.Split('/')[0] }
        $zip.Dispose()
        return $top
    } catch {
        return $null
    }
}

# Temp Python script that Blender itself will run to install + enable the addon
$installerPy = Join-Path $env:TEMP "blenderai_addon_install.py"
@'
import sys, bpy
argv = sys.argv
argv = argv[argv.index("--") + 1:]
zip_path = argv[0]
module_name = argv[1] if len(argv) > 1 else None

bpy.ops.preferences.addon_install(filepath=zip_path, overwrite=True)

if module_name:
    try:
        bpy.ops.preferences.addon_enable(module=module_name)
    except Exception as e:
        print("ADDON_ENABLE_FAILED:", e)

bpy.ops.wm.save_userpref()
print("ADDON_INSTALL_OK")
'@ | Set-Content -Path $installerPy -Encoding UTF8

$blenders = Get-BlenderInstalls

if (-not $blenders -or $blenders.Count -eq 0) {
    Write-Output "NO_BLENDER_FOUND"
    exit 0
}

foreach ($exe in $blenders) {
    $verLine = Get-BlenderVersionString -BlenderExe $exe
    $minor = Get-BlenderPythonMinor -BlenderExe $exe

    if (-not $minor) {
        Write-Output "SKIP|$exe|$verLine|could not detect its Python version"
        continue
    }

    $zipMatch = Get-ChildItem -Path $ScriptDir -Filter "*cp$minor*.zip" -File -ErrorAction SilentlyContinue | Select-Object -First 1

    if (-not $zipMatch) {
        Write-Output "SKIP|$exe|$verLine|no addon zip matches Python 3.$minor"
        continue
    }

    $moduleName = Get-ZipTopFolder -ZipPath $zipMatch.FullName

    $result = & $exe -b --python $installerPy -- "$($zipMatch.FullName)" "$moduleName" 2>&1

    if ($result -match "ADDON_INSTALL_OK") {
        Write-Output "OK|$exe|$verLine|$($zipMatch.Name)"
    } else {
        Write-Output "FAIL|$exe|$verLine|$($zipMatch.Name)"
    }
}
