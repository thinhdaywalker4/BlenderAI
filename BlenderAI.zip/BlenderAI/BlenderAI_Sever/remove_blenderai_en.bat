@echo off
setlocal EnableDelayedExpansion
title BlenderAI - Uninstall

echo ================================================
echo   BlenderAI - Uninstall
echo ================================================
echo.

REM --- 1. Remove pip package from every Python 3.10-3.14 that has blenderai installed ---
where py >nul 2>&1
if errorlevel 1 (
    echo [WARNING] "py launcher" not found, skipping pip package removal step.
    goto :remove_config
)

echo Checking which Python installations have the "blenderai" package...
for %%V in (3.10 3.11 3.12 3.13 3.14) do (
    py -%%V -c "import sys" >nul 2>&1
    if not errorlevel 1 (
        py -%%V -m pip show blenderai >nul 2>&1
        if not errorlevel 1 (
            echo [FOUND] Python %%V has blenderai installed -^> removing...
            py -%%V -m pip uninstall -y blenderai
            if errorlevel 1 (
                echo   [WARNING] Removal failed on Python %%V, see log above.
            ) else (
                echo   [OK] blenderai removed from Python %%V
            )
        )
    )
)
echo.

:remove_config
REM --- 2. Restore claude_desktop_config.json from the most recent .bak file ---
REM (this .bak file was created by the install step before it overwrote the config)
echo Restoring Claude Desktop configuration from backup file...

set "CFG1_DIR=%APPDATA%\Claude"
set "CFG1_FILE=%CFG1_DIR%\claude_desktop_config.json"

set "CFG2_DIR="
for /d %%D in ("%LOCALAPPDATA%\Packages\Claude_*") do set "CFG2_DIR=%%D\LocalCache\Roaming\Claude"
if defined CFG2_DIR set "CFG2_FILE=%CFG2_DIR%\claude_desktop_config.json"

call :RESTORE_ONE_CONFIG "%CFG1_DIR%" "%CFG1_FILE%" "normal"

if defined CFG2_DIR (
    call :RESTORE_ONE_CONFIG "%CFG2_DIR%" "%CFG2_FILE%" "MSIX"
)
echo.

REM --- 3. Find and ask to delete the addon in each Blender installation ---
echo Checking for the BlenderAI addon in Blender folders...
set "FOUND_ANY=0"
for /d %%D in ("%APPDATA%\Blender Foundation\Blender\*") do (
    if exist "%%D\scripts\addons\BlenderAI" (
        set "FOUND_ANY=1"
        echo   Found: %%D\scripts\addons\BlenderAI
    )
)

if "!FOUND_ANY!"=="0" (
    echo   BlenderAI addon not found in any Blender version.
    goto :done
)

echo.
set /p CONFIRM="Delete ALL of the BlenderAI addon folders listed above? (Y/N): "
if /i "!CONFIRM!"=="Y" (
    for /d %%D in ("%APPDATA%\Blender Foundation\Blender\*") do (
        if exist "%%D\scripts\addons\BlenderAI" (
            rd /s /q "%%D\scripts\addons\BlenderAI"
            echo   [OK] Deleted %%D\scripts\addons\BlenderAI
        )
    )
) else (
    echo   Skipped, addon not deleted. You can remove it manually later.
)

:done
echo.
echo ================================================
echo   UNINSTALL COMPLETE.
echo   Please restart Claude Desktop / Blender if they are open.
echo ================================================
pause
exit /b 0

REM ============================================================
REM Subroutine: RESTORE_ONE_CONFIG "<target dir>" "<target file>" "<label>"
REM Finds the most recent claude_desktop_config.json.bak_* file in
REM the target directory (sorted by name; since the timestamp
REM format is YYYYMMDD_HHMMSS, sorting by name equals sorting by
REM time), then copies it over the current config file (restoring
REM the original before BlenderAI overwrote it).
REM ============================================================
:RESTORE_ONE_CONFIG
set "R_DIR=%~1"
set "R_FILE=%~2"
set "R_LABEL=%~3"

if not exist "%R_DIR%" (
    echo   [!] %R_LABEL% folder not found: %R_DIR%, skipping.
    goto :EOF
)

set "R_BAK="
for /f "delims=" %%F in ('dir /b /o-n "%R_DIR%\claude_desktop_config.json.bak_*" 2^>nul') do (
    if not defined R_BAK set "R_BAK=%%F"
)

if not defined R_BAK (
    echo   [!] No backup file found in %R_LABEL% ^(%R_DIR%^), skipping restore.
    goto :EOF
)

copy /Y "%R_DIR%\%R_BAK%" "%R_FILE%" >nul
if errorlevel 1 (
    echo   [X] Failed to restore %R_LABEL% config from file: %R_BAK%
) else (
    echo   [OK] Restored %R_LABEL% config from backup file: %R_BAK%
)

goto :EOF
